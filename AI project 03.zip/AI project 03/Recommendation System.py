# AI Recommendation System

items = [
    {"name": "Kalki 2898 AD", "genre": ["sci-fi", "thriller", "action"]},
    {"name": "Little Hearts", "genre": ["romance", "drama"]},
    {"name": "Eega", "genre": ["action", "sci-fi"]},
    {"name": "Geetha Govindham", "genre": ["romance", "drama"]},
    {"name": "24", "genre": ["sci-fi", "drama"]},
    {"name": "John Wick", "genre": ["action", "thriller"]},
]

user_input = input("Enter your preferred genres (comma-separated): ").lower()
user_preferences = [genre.strip() for genre in user_input.split(",")]

recommendations = []

for item in items:
    score = 0
    for pref in user_preferences:
        if pref in item["genre"]:
            score += 1
    recommendations.append((item["name"], score))

recommendations.sort(key=lambda x: x[1], reverse=True)

print("\nRecommended Items:\n")

found = False
for item, score in recommendations:
    if score > 0:
        print(f"{item} (Match Score: {score})")
        found = True

if not found:
    print("No strong matches found.")